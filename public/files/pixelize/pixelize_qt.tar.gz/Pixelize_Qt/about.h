#ifndef ABOUT_H
#define ABOUT_H

#include <QApplication>
#include <QDesktopWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QPixmap>
#include <QIcon>
#include <QFont>

class About : public QWidget
{
    public:
        About(QWidget *parent = 0);

};

#endif // ABOUT_H
